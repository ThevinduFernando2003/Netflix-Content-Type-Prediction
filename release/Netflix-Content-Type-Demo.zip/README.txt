﻿Netflix content-type demo package

screenshots\   Full-page captures of the local Streamlit UI and the API docs.
demo_video\    Walkthrough (demo.webm) of the same screens, including scored examples and Wikipedia posters.
scripts\       capture_demo.py, the Playwright script that recorded these files against the local API and UI.
